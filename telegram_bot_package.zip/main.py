import os
import telebot
from flask import Flask, request

TOKEN = os.environ.get('BOT_TOKEN')
bot = telebot.TeleBot(TOKEN)
app = Flask(__name__)

@app.route('/' + TOKEN, methods=['POST'])
def getMessage():
    json_str = request.get_data().decode('UTF-8')
    update = telebot.types.Update.de_json(json_str)
    bot.process_new_updates([update])
    return '!', 200

@app.route('/')
def webhook():
    bot.remove_webhook()
    bot.set_webhook(url=os.environ.get('RENDER_EXTERNAL_URL') + TOKEN)
    return '!', 200

@bot.message_handler(commands=['start'])
def start(message):
    markup = telebot.types.InlineKeyboardMarkup()
    btn = telebot.types.InlineKeyboardButton(text='✅ Я был активным', callback_data='active')
    markup.add(btn)
    bot.send_message(message.chat.id, 'Рада Вас приветствовать!

Если Вы были активны на этой неделе — ставили реакции, писали, делились — нажмите кнопку ниже, и я подарю Вам полезный мини-гайд 💚', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == 'active')
def callback_active(call):
    with open("gift.pdf", "rb") as file:
        bot.send_document(call.message.chat.id, file, caption="Спасибо! Вот ваш подарок недели 🎁")

    bot.answer_callback_query(call.id)